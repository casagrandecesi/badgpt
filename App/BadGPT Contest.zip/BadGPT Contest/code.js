var webpage = "https://www.casagrande-cesi.it/badgpt/index.html";
var invio_in_corso = false;
onEvent("button_regole", "click", function( ) {
  if (invio_in_corso) return;
	setScreen("screen_regolamento");
});
onEvent("button_indietro_regole", "click", function( ) {
	setScreen("screen_invia");
});
onEvent("button_invia", "click", function( ) {
  if (invio_in_corso) return;
  var risposta = getText("text_area_risposta");
  var email = getText("text_input_email");
  var ok = true;
  if (!risposta.trim()) {
    ok = false;
    setProperty("text_area_risposta", "border-color", "#eb1260");
  } else {
    setProperty("text_area_risposta", "border-color", "#040548");
  }
  if (!email.trim() || !email.match(
    /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
  )) {
    ok = false;
    setProperty("text_input_email", "border-color", "#eb1260");
  } else {
    setProperty("text_input_email", "border-color", "#040548");
  }
  if (ok) {
    invio_in_corso = true;
    // OK qui bariamo un po' ma abbiamo visto che startWebRequest ci fa usare una lista limitata
    // di domini, quindi ricorriamo al "vecchio trucco del pixel spia" (almeno così dice il prof...)
    var url = "https://www.casagrande-cesi.it/badgpt/mailer.php?password=c140bLulla";
    url = url + "&answer=" + encodeURIComponent(risposta);
    url = url + "&email=" + encodeURIComponent(email);
    setImageURL("image_mailer", url);
    setTimeout(function () {
      setScreen("screen_grazie");
      invio_in_corso = false;
    }, 1000);
    //startWebRequest(url, function(status, type, content) {
    //  console.log(status);
    //  console.log(url);
    //  console.log(content);
    //  setScreen("screen_grazie");
    //});
  }
});
onEvent("button_indietro_grazie", "click", function( ) {
	setScreen("screen_invia");
});
function tuttoInglese() {
  setProperty("button_invia", "text", "SUBMIT");
	setProperty("button_regole", "text", "RULES");
	setProperty("label_risposta", "text", "Wrong ChatGPT answer");
	setProperty("label_email", "text", "Email address");
	setProperty("text_area_regole", "text", "Did you know that modern generative artificial intelligence, like ChatGPT, is far from flawless? Some answers may be spectacularly wrong: this is inevitable, due to the data used to train them and the algorithms on which they are based.\n\nThe BadGPT contest refers in particular to ChatGPT: send an incorrect ChatGPT answer and, if our jury deems it the best (and funnies), you can win the exclusive \"GPTBreaker\" badge!\n\nThere are a few simple rules:\n\n1. You may submit as many responses as you want\n2. You have to send wrong answers written directly by ChatGPT\n3. The answers must be verifiable: ChatGPT must be able to confirm that it produced the text by itself\n4. The answers can be submitted up to 23:59 of June 30, 2024 (Rome time zone)\n\nBreak a leg!");
	setProperty("button_indietro_regole", "text", "BACK");
	setProperty("button_indietro_grazie", "text", "BACK");
  setProperty("label_grazie", "text", "Thank you for your answer... break a leg!!!");
  setProperty("label_scaduto", "text", "The contest is over, I'm sorry.");
  webpage = "https://www.casagrande-cesi.it/badgpt/index-en.html";

}
function tuttoItaliano() {
  setProperty("button_invia", "text", "INVIA");
	setProperty("button_regole", "text", "REGOLE");
	setProperty("label_risposta", "text", "Risposta errata di ChatGPT");
	setProperty("label_email", "text", "Indirizzo email");
	setProperty("text_area_regole", "text", "Sapevi che le moderne intelligenze artificiali generative, come ChatGPT, non sono infallibili? Alcune risposte possono essere clamorosamente sbagliate: è inevitabile, a causa dei dati usati per il loro addestramento e gli algoritmi su cui sono basate.\n\nQuesto concorso, il BadGPT contest, si riferisce in particolare a ChatGPT: invia una risposta errata prodotta da ChatGPT e, se la nostra giuria la riterrà la migliore (nonché la più divertente), potrai vincere l'esclusivo badge \"GPTBreaker\"!\n\nCi sono poche semplici regole:\n\n1. Puoi inviare quante risposte vuoi\n2. Devi inviare risposte errate prodotte direttamente da ChatGPT\n3. Le risposte errate devono essere verificabili: ChatGPT deve poter confermare di aver prodotto il testo\n4. Le risposte devono essere inviate entro le 23:59 del 30 giugno 2024 (fuso orario di Roma)\n\nIn bocca al lupo!")
	setProperty("button_indietro_regole", "text", "INDIETRO");
	setProperty("button_indietro_grazie", "text", "INDIETRO");
	setProperty("label_grazie", "text", "Grazie per la risposta... in bocca al lupo!!!");
	setProperty("label_scaduto", "text", "Il concorso è chiuso, mi dispiace.");
	webpage = "https://www.casagrande-cesi.it/badgpt/index.html";
}
onEvent("image_eng_invia", "click", function( ) {
  tuttoInglese();
});
onEvent("image_ita_invia", "click", function( ) {
	tuttoItaliano();
});
onEvent("image_eng_regole", "click", function( ) {
	tuttoInglese();
});
onEvent("image_ita_regole", "click", function( ) {
	tuttoItaliano();
});
onEvent("label_sito", "click", function( ) {
	open(webpage);
});
onEvent("label_sito_scaduto", "click", function( ) {
	open(webpage);
});
// Codice principale
tuttoItaliano();
setScreen("screen_inizio");
setTimeout(function() {
  var limite = 1719784799000; // 2024-06-30 23:59:59 Rome... grazie a www.epochconverter.com!
  var ora = getTime();
  if (ora < limite)
    setScreen("screen_invia");
  else
    setScreen("screen_scaduto");
}, 2000);
